#11) 11. UPDATING FROM A STRING

string_1 = input()
string_2 = input()

#Updating the indexes
updated_string = string_1[:2] + string_2[2] + string_1[3:]

print(updated_string)